export type QuestionInputProps = {
    isEditMode?: boolean
}